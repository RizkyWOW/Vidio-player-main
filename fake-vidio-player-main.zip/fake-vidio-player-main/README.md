Fake Vidio player

Access cam
location 
send notification to telegram
change telegram bot token in file
